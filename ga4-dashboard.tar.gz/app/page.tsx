import StatTile from "@/components/StatTile";
import TrendChart from "@/components/TrendChart";
import ChannelBarChart from "@/components/ChannelBarChart";
import FunnelChart from "@/components/FunnelChart";
import TopPagesTable from "@/components/TopPagesTable";
import { getDashboardData } from "@/lib/dashboard";

export const dynamic = "force-dynamic";

export default async function Home() {
  const data = await getDashboardData();
  const usersSpark = data.daily.map((d) => d.users);
  const sessionsSpark = data.daily.map((d) => d.sessions);

  return (
    <div className="viz-root min-h-screen px-6 py-8 max-w-5xl mx-auto flex flex-col gap-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>
          GA4 Performance Dashboard
        </h1>
        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
          {data.propertyLabel} · {data.range.start} → {data.range.end}
        </p>
        {data.source === "mock" && (
          <div
            className="mt-2 text-xs rounded-md px-3 py-2"
            style={{ background: "var(--status-warning)", color: "#1a1400" }}
          >
            Live GA4 fetch failed, showing sample data instead. {data.error}
          </div>
        )}
      </header>

      <section className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatTile label="Users" value={data.kpis.users.value.toLocaleString()} deltaPct={data.kpis.users.deltaPct} sparkline={usersSpark} />
        <StatTile label="Sessions" value={data.kpis.sessions.value.toLocaleString()} deltaPct={data.kpis.sessions.deltaPct} sparkline={sessionsSpark} />
        <StatTile
          label="Engagement rate"
          value={`${(data.kpis.engagementRate.value * 100).toFixed(1)}%`}
          deltaPct={data.kpis.engagementRate.deltaPct}
        />
        <StatTile label="Conversions" value={data.kpis.conversions.value.toLocaleString()} deltaPct={data.kpis.conversions.deltaPct} />
        <StatTile
          label="Revenue"
          value={data.kpis.revenue.value.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 })}
          deltaPct={data.kpis.revenue.deltaPct}
        />
      </section>

      <TrendChart data={data.daily} />

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChannelBarChart data={data.channels} />
        <FunnelChart data={data.funnel} />
      </section>

      <TopPagesTable data={data.topPages} />

      <footer className="text-xs pb-4" style={{ color: "var(--text-muted)" }}>
        {data.source === "live" ? "Live data from your GA4 property." : "Sample data for preview purposes."}
      </footer>
    </div>
  );
}
