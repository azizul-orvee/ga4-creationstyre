"use client";

import { useMemo, useState } from "react";
import type { DailyPoint } from "@/lib/mockData";

type Props = { data: DailyPoint[] };

const WIDTH = 720;
const HEIGHT = 260;
const PAD_L = 44;
const PAD_R = 16;
const PAD_T = 16;
const PAD_B = 28;

export default function TrendChart({ data }: Props) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const { usersPath, sessionsPath, xFor, yFor, ticksY } = useMemo(() => {
    const maxVal = Math.max(...data.map((d) => Math.max(d.users, d.sessions)));
    const niceMax = Math.ceil(maxVal / 500) * 500;
    const innerW = WIDTH - PAD_L - PAD_R;
    const innerH = HEIGHT - PAD_T - PAD_B;
    const xFor = (i: number) => PAD_L + (i / (data.length - 1)) * innerW;
    const yFor = (v: number) => PAD_T + innerH - (v / niceMax) * innerH;

    const line = (key: "users" | "sessions") =>
      data.map((d, i) => `${i === 0 ? "M" : "L"}${xFor(i).toFixed(1)},${yFor(d[key]).toFixed(1)}`).join(" ");

    const ticksY = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(niceMax * f));

    return { usersPath: line("users"), sessionsPath: line("sessions"), xFor, yFor, ticksY };
  }, [data]);

  const hovered = hoverIdx !== null ? data[hoverIdx] : null;

  return (
    <div className="viz-root rounded-lg border p-4" style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>
          Users &amp; sessions — last 30 days
        </h3>
        <div className="flex items-center gap-4 text-xs" style={{ color: "var(--text-secondary)" }}>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: "var(--series-1)" }} />
            Users
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: "var(--series-2)" }} />
            Sessions
          </span>
        </div>
      </div>

      <svg
        width="100%"
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        role="img"
        aria-label="Line chart of daily users and sessions over the last 30 days"
        onMouseLeave={() => setHoverIdx(null)}
        onMouseMove={(e) => {
          const svg = e.currentTarget;
          const rect = svg.getBoundingClientRect();
          const relX = ((e.clientX - rect.left) / rect.width) * WIDTH;
          const innerW = WIDTH - PAD_L - PAD_R;
          const idx = Math.round(((relX - PAD_L) / innerW) * (data.length - 1));
          if (idx >= 0 && idx < data.length) setHoverIdx(idx);
        }}
      >
        {ticksY.map((t) => (
          <g key={t}>
            <line x1={PAD_L} x2={WIDTH - PAD_R} y1={yFor(t)} y2={yFor(t)} stroke="var(--gridline)" strokeWidth="1" />
            <text x={PAD_L - 8} y={yFor(t) + 3} textAnchor="end" fontSize="10" fill="var(--text-muted)">
              {t.toLocaleString()}
            </text>
          </g>
        ))}
        <line x1={PAD_L} x2={WIDTH - PAD_R} y1={HEIGHT - PAD_B} y2={HEIGHT - PAD_B} stroke="var(--baseline)" strokeWidth="1" />

        <path d={sessionsPath} fill="none" stroke="var(--series-2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d={usersPath} fill="none" stroke="var(--series-1)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />

        {hoverIdx !== null && (
          <>
            <line
              x1={xFor(hoverIdx)}
              x2={xFor(hoverIdx)}
              y1={PAD_T}
              y2={HEIGHT - PAD_B}
              stroke="var(--text-muted)"
              strokeWidth="1"
              strokeDasharray="3,3"
            />
            <circle cx={xFor(hoverIdx)} cy={yFor(data[hoverIdx].users)} r="4" fill="var(--series-1)" stroke="var(--surface-1)" strokeWidth="2" />
            <circle cx={xFor(hoverIdx)} cy={yFor(data[hoverIdx].sessions)} r="4" fill="var(--series-2)" stroke="var(--surface-1)" strokeWidth="2" />
          </>
        )}
      </svg>

      <div className="h-6 text-xs tabular-nums" style={{ color: "var(--text-secondary)" }}>
        {hovered ? (
          <span>
            {hovered.date} · Users {hovered.users.toLocaleString()} · Sessions {hovered.sessions.toLocaleString()}
          </span>
        ) : (
          <span style={{ color: "var(--text-muted)" }}>Hover the chart to inspect a day</span>
        )}
      </div>
    </div>
  );
}
