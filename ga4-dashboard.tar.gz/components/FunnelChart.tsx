import type { FunnelStage } from "@/lib/mockData";

type Props = { data: FunnelStage[] };

const STEP_VARS = ["--seq-700", "--seq-550", "--seq-450", "--seq-250", "--seq-100"];

export default function FunnelChart({ data }: Props) {
  const max = data[0]?.users || 1;

  return (
    <div className="viz-root rounded-lg border p-4" style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}>
      <h3 className="text-sm font-medium mb-3" style={{ color: "var(--text-primary)" }}>
        Conversion funnel
      </h3>
      <div className="flex flex-col gap-2">
        {data.map((stage, i) => {
          const pct = (stage.users / max) * 100;
          const dropFromPrev = i === 0 ? null : ((data[i - 1].users - stage.users) / data[i - 1].users) * 100;
          return (
            <div key={stage.stage}>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
                  {stage.stage}
                </span>
                <span className="text-xs tabular-nums" style={{ color: "var(--text-primary)" }}>
                  {stage.users.toLocaleString()}
                  {dropFromPrev !== null && (
                    <span style={{ color: "var(--status-critical)" }}> · -{dropFromPrev.toFixed(0)}%</span>
                  )}
                </span>
              </div>
              <div className="h-6 rounded-sm" style={{ background: "var(--gridline)" }}>
                <div
                  className="h-6 rounded-sm"
                  style={{ width: `${pct}%`, background: `var(${STEP_VARS[Math.min(i, STEP_VARS.length - 1)]})` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
