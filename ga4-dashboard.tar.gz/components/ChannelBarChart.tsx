"use client";

import { useState } from "react";
import type { ChannelRow } from "@/lib/mockData";

type Props = { data: ChannelRow[] };

export default function ChannelBarChart({ data }: Props) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const max = Math.max(...data.map((d) => d.sessions));

  return (
    <div className="viz-root rounded-lg border p-4" style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}>
      <h3 className="text-sm font-medium mb-3" style={{ color: "var(--text-primary)" }}>
        Sessions by acquisition channel
      </h3>
      <div className="flex flex-col gap-2.5">
        {data.map((row, i) => {
          const pct = (row.sessions / max) * 100;
          const isHover = hoverIdx === i;
          return (
            <div
              key={row.channel}
              className="grid items-center gap-3"
              style={{ gridTemplateColumns: "120px 1fr 64px" }}
              onMouseEnter={() => setHoverIdx(i)}
              onMouseLeave={() => setHoverIdx(null)}
            >
              <span className="text-xs truncate" style={{ color: "var(--text-secondary)" }}>
                {row.channel}
              </span>
              <div className="h-5 rounded-sm" style={{ background: "var(--gridline)" }}>
                <div
                  className="h-5 rounded-sm transition-[width]"
                  style={{
                    width: `${pct}%`,
                    background: "var(--seq-450)",
                    opacity: isHover ? 1 : 0.9,
                    outline: isHover ? "2px solid var(--surface-1)" : "none",
                    outlineOffset: "-2px",
                  }}
                />
              </div>
              <span className="text-xs tabular-nums text-right" style={{ color: "var(--text-primary)" }}>
                {row.sessions.toLocaleString()}
              </span>
            </div>
          );
        })}
      </div>
      {hoverIdx !== null && (
        <div className="mt-3 text-xs tabular-nums" style={{ color: "var(--text-secondary)" }}>
          {data[hoverIdx].channel}: {data[hoverIdx].sessions.toLocaleString()} sessions,{" "}
          {data[hoverIdx].conversions.toLocaleString()} conversions (
          {((data[hoverIdx].conversions / data[hoverIdx].sessions) * 100).toFixed(1)}% CVR)
        </div>
      )}
    </div>
  );
}
