type Props = {
  label: string;
  value: string;
  deltaPct: number;
  sparkline?: number[];
};

export default function StatTile({ label, value, deltaPct, sparkline }: Props) {
  const isUp = deltaPct >= 0;
  const deltaColor = isUp ? "var(--success-text)" : "var(--status-critical)";
  const path = sparkline ? buildSparklinePath(sparkline) : null;

  return (
    <div
      className="viz-root rounded-lg border p-4 flex flex-col gap-2"
      style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}
    >
      <div className="text-sm" style={{ color: "var(--text-secondary)" }}>
        {label}
      </div>
      <div className="flex items-end justify-between gap-3">
        <div
          className="text-2xl font-semibold tabular-nums"
          style={{ color: "var(--text-primary)" }}
        >
          {value}
        </div>
        {path && (
          <svg width="64" height="24" viewBox="0 0 64 24" aria-hidden="true">
            <path d={path} fill="none" stroke="var(--series-1)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </div>
      <div className="text-xs font-medium tabular-nums" style={{ color: deltaColor }}>
        {isUp ? "↑" : "↓"} {Math.abs(deltaPct).toFixed(1)}% vs prior period
      </div>
    </div>
  );
}

function buildSparklinePath(values: number[]) {
  const w = 64;
  const h = 24;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  const stepX = w / (values.length - 1);
  return values
    .map((v, i) => {
      const x = i * stepX;
      const y = h - ((v - min) / range) * (h - 4) - 2;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}
