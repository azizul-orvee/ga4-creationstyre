import type { PageRow } from "@/lib/mockData";

type Props = { data: PageRow[] };

export default function TopPagesTable({ data }: Props) {
  return (
    <div className="viz-root rounded-lg border p-4" style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}>
      <h3 className="text-sm font-medium mb-3" style={{ color: "var(--text-primary)" }}>
        Top pages
      </h3>
      <table className="w-full text-xs">
        <thead>
          <tr style={{ borderBottom: "1px solid var(--gridline)" }}>
            <th className="text-left font-medium py-1.5" style={{ color: "var(--text-muted)" }}>
              Page
            </th>
            <th className="text-right font-medium py-1.5 tabular-nums" style={{ color: "var(--text-muted)" }}>
              Views
            </th>
            <th className="text-right font-medium py-1.5 tabular-nums" style={{ color: "var(--text-muted)" }}>
              Avg. engagement
            </th>
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row.path} style={{ borderBottom: "1px solid var(--gridline)" }}>
              <td className="py-1.5 truncate max-w-[220px]" style={{ color: "var(--text-primary)" }}>
                {row.path}
              </td>
              <td className="py-1.5 text-right tabular-nums" style={{ color: "var(--text-primary)" }}>
                {row.views.toLocaleString()}
              </td>
              <td className="py-1.5 text-right tabular-nums" style={{ color: "var(--text-secondary)" }}>
                {row.avgEngagement}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
