import { getMockDashboardData, type DashboardData } from "./mockData";
import { getLiveDashboardData } from "./ga4";

export type DashboardResult = DashboardData & { source: "live" | "mock"; error?: string };

export async function getDashboardData(): Promise<DashboardResult> {
  try {
    const data = await getLiveDashboardData();
    return { ...data, source: "live" };
  } catch (err) {
    console.error("GA4 live fetch failed, falling back to mock data:", err);
    const data = getMockDashboardData();
    return {
      ...data,
      source: "mock",
      error: err instanceof Error ? err.message : "Unknown error fetching GA4 data",
    };
  }
}
