import { BetaAnalyticsDataClient } from "@google-analytics/data";
import path from "path";
import fs from "fs";
import type { DashboardData, DailyPoint, ChannelRow, PageRow, FunnelStage } from "./mockData";

function getClient() {
  // Preferred for deployment (e.g. Vercel): paste the whole JSON key into
  // GA4_SERVICE_ACCOUNT_KEY_JSON as an env var — no file needed.
  const inlineJson = process.env.GA4_SERVICE_ACCOUNT_KEY_JSON;
  if (inlineJson) {
    const credentials = JSON.parse(inlineJson);
    return new BetaAnalyticsDataClient({ credentials });
  }

  // Fallback for local dev: a path to the key file on disk.
  const keyPath = process.env.GA4_SERVICE_ACCOUNT_KEY_PATH;
  if (!keyPath) {
    throw new Error("Set GA4_SERVICE_ACCOUNT_KEY_JSON (recommended) or GA4_SERVICE_ACCOUNT_KEY_PATH");
  }
  const resolved = path.isAbsolute(keyPath) ? keyPath : path.join(process.cwd(), /* turbopackIgnore: true */ keyPath);
  if (!fs.existsSync(resolved)) throw new Error(`GA4 service account key not found at ${resolved}`);
  return new BetaAnalyticsDataClient({ keyFilename: resolved });
}

function propertyPath() {
  const id = process.env.GA4_PROPERTY_ID;
  if (!id) throw new Error("GA4_PROPERTY_ID is not set");
  return `properties/${id}`;
}

function pct(curr: number, prev: number) {
  if (!prev) return 0;
  return ((curr - prev) / prev) * 100;
}

export async function getLiveDashboardData(): Promise<DashboardData> {
  const client = getClient();
  const property = propertyPath();

  const [dailyReport, currTotalsReport, prevTotalsReport, channelReport, pageReport, funnelReport] = await Promise.all([
    client.runReport({
      property,
      dateRanges: [{ startDate: "29daysAgo", endDate: "today" }],
      dimensions: [{ name: "date" }],
      metrics: [{ name: "totalUsers" }, { name: "sessions" }],
      orderBys: [{ dimension: { dimensionName: "date" } }],
    }),
    client.runReport({
      property,
      dateRanges: [{ startDate: "29daysAgo", endDate: "today" }],
      metrics: [{ name: "totalUsers" }, { name: "sessions" }, { name: "engagementRate" }, { name: "conversions" }, { name: "totalRevenue" }],
    }),
    client.runReport({
      property,
      dateRanges: [{ startDate: "59daysAgo", endDate: "30daysAgo" }],
      metrics: [{ name: "totalUsers" }, { name: "sessions" }, { name: "engagementRate" }, { name: "conversions" }, { name: "totalRevenue" }],
    }),
    client.runReport({
      property,
      dateRanges: [{ startDate: "29daysAgo", endDate: "today" }],
      dimensions: [{ name: "sessionDefaultChannelGroup" }],
      metrics: [{ name: "sessions" }, { name: "conversions" }],
      orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
      limit: 10,
    }),
    client.runReport({
      property,
      dateRanges: [{ startDate: "29daysAgo", endDate: "today" }],
      dimensions: [{ name: "pagePath" }],
      metrics: [{ name: "screenPageViews" }, { name: "averageSessionDuration" }],
      orderBys: [{ metric: { metricName: "screenPageViews" }, desc: true }],
      limit: 5,
    }),
    client.runReport({
      property,
      dateRanges: [{ startDate: "29daysAgo", endDate: "today" }],
      metrics: [{ name: "sessions" }, { name: "screenPageViews" }, { name: "addToCarts" }, { name: "checkouts" }, { name: "ecommercePurchases" }],
    }),
  ]);

  const [dailyResp] = dailyReport;
  const [currResp] = currTotalsReport;
  const [prevResp] = prevTotalsReport;
  const [channelResp] = channelReport;
  const [pageResp] = pageReport;
  const [funnelResp] = funnelReport;

  const daily: DailyPoint[] = (dailyResp.rows ?? []).map((row) => {
    const raw = row.dimensionValues?.[0]?.value ?? "";
    const date = `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
    return {
      date,
      users: Number(row.metricValues?.[0]?.value ?? 0),
      sessions: Number(row.metricValues?.[1]?.value ?? 0),
    };
  });

  const currRow = currResp.rows?.[0];
  const totalUsers = Number(currRow?.metricValues?.[0]?.value ?? 0);
  const totalSessions = Number(currRow?.metricValues?.[1]?.value ?? 0);
  const engagementRate = Number(currRow?.metricValues?.[2]?.value ?? 0);
  const totalConversions = Number(currRow?.metricValues?.[3]?.value ?? 0);
  const revenue = Number(currRow?.metricValues?.[4]?.value ?? 0);

  const prevRow = prevResp.rows?.[0];
  const prevUsers = Number(prevRow?.metricValues?.[0]?.value ?? 0);
  const prevSessions = Number(prevRow?.metricValues?.[1]?.value ?? 0);
  const prevEngagement = Number(prevRow?.metricValues?.[2]?.value ?? 0);
  const prevConversions = Number(prevRow?.metricValues?.[3]?.value ?? 0);
  const prevRevenue = Number(prevRow?.metricValues?.[4]?.value ?? 0);

  const channels: ChannelRow[] = (channelResp.rows ?? []).map((row) => ({
    channel: row.dimensionValues?.[0]?.value ?? "Unknown",
    sessions: Number(row.metricValues?.[0]?.value ?? 0),
    conversions: Number(row.metricValues?.[1]?.value ?? 0),
  }));

  const topPages: PageRow[] = (pageResp.rows ?? []).map((row) => {
    const secs = Number(row.metricValues?.[1]?.value ?? 0);
    const m = Math.floor(secs / 60);
    const s = Math.round(secs % 60);
    return {
      path: row.dimensionValues?.[0]?.value ?? "/",
      views: Number(row.metricValues?.[0]?.value ?? 0),
      avgEngagement: `${m}:${s.toString().padStart(2, "0")}`,
    };
  });

  const fRow = funnelResp.rows?.[0];
  const funnel: FunnelStage[] = [
    { stage: "Sessions", users: Number(fRow?.metricValues?.[0]?.value ?? 0) },
    { stage: "Page views", users: Number(fRow?.metricValues?.[1]?.value ?? 0) },
    { stage: "Add to cart", users: Number(fRow?.metricValues?.[2]?.value ?? 0) },
    { stage: "Checkout started", users: Number(fRow?.metricValues?.[3]?.value ?? 0) },
    { stage: "Purchase", users: Number(fRow?.metricValues?.[4]?.value ?? 0) },
  ];

  return {
    propertyLabel: `GA4 property ${process.env.GA4_PROPERTY_ID}`,
    range: { start: daily[0]?.date ?? "", end: daily[daily.length - 1]?.date ?? "" },
    kpis: {
      users: { value: totalUsers, deltaPct: pct(totalUsers, prevUsers) },
      sessions: { value: totalSessions, deltaPct: pct(totalSessions, prevSessions) },
      engagementRate: { value: engagementRate, deltaPct: pct(engagementRate, prevEngagement) },
      conversions: { value: totalConversions, deltaPct: pct(totalConversions, prevConversions) },
      revenue: { value: revenue, deltaPct: pct(revenue, prevRevenue) },
    },
    daily,
    channels,
    topPages,
    funnel,
  };
}
