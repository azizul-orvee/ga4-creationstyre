// Mock data shaped like real GA4 Data API responses.
// Swap `lib/ga4.ts` for real API calls once credentials are wired up —
// the shape here is what the dashboard consumes either way.

export type DailyPoint = { date: string; users: number; sessions: number };
export type ChannelRow = { channel: string; sessions: number; conversions: number };
export type PageRow = { path: string; views: number; avgEngagement: string };
export type FunnelStage = { stage: string; users: number };

function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

export function getMockDashboardData() {
  const rand = seededRandom(42);
  const today = new Date("2026-08-15T00:00:00Z");
  const daily: DailyPoint[] = [];

  let baseUsers = 1450;
  for (let i = 29; i >= 0; i--) {
    const d = new Date(today);
    d.setUTCDate(d.getUTCDate() - i);
    const wobble = (rand() - 0.5) * 260;
    const weekday = d.getUTCDay();
    const weekendDip = weekday === 0 || weekday === 6 ? -220 : 0;
    const trendUp = (29 - i) * 6;
    const users = Math.max(300, Math.round(baseUsers + wobble + weekendDip + trendUp));
    const sessions = Math.round(users * (1.18 + rand() * 0.12));
    daily.push({ date: d.toISOString().slice(0, 10), users, sessions });
  }

  const channels: ChannelRow[] = [
    { channel: "Organic Search", sessions: 18420, conversions: 612 },
    { channel: "Direct", sessions: 9860, conversions: 301 },
    { channel: "Paid Social", sessions: 7210, conversions: 244 },
    { channel: "Organic Social", sessions: 4330, conversions: 96 },
    { channel: "Referral", sessions: 3120, conversions: 88 },
    { channel: "Email", sessions: 2040, conversions: 121 },
  ].sort((a, b) => b.sessions - a.sessions);

  const topPages: PageRow[] = [
    { path: "/", views: 24810, avgEngagement: "0:42" },
    { path: "/pricing", views: 9640, avgEngagement: "1:15" },
    { path: "/blog/ga4-migration-guide", views: 7220, avgEngagement: "3:04" },
    { path: "/product/features", views: 6110, avgEngagement: "1:52" },
    { path: "/contact", views: 4380, avgEngagement: "0:38" },
  ];

  const funnel: FunnelStage[] = [
    { stage: "Sessions", users: 45080 },
    { stage: "Product views", users: 19340 },
    { stage: "Add to cart", users: 6720 },
    { stage: "Checkout started", users: 2810 },
    { stage: "Purchase", users: 1462 },
  ];

  const totalUsers = daily.reduce((s, d) => s + d.users, 0);
  const totalSessions = daily.reduce((s, d) => s + d.sessions, 0);
  const totalConversions = channels.reduce((s, c) => s + c.conversions, 0);
  const revenue = totalConversions * 68.4;

  return {
    propertyLabel: "Mock GA4 Property (sample data)",
    range: { start: daily[0].date, end: daily[daily.length - 1].date },
    kpis: {
      users: { value: totalUsers, deltaPct: 8.4 },
      sessions: { value: totalSessions, deltaPct: 5.1 },
      engagementRate: { value: 0.612, deltaPct: -1.8 },
      conversions: { value: totalConversions, deltaPct: 14.2 },
      revenue: { value: revenue, deltaPct: 11.6 },
    },
    daily,
    channels,
    topPages,
    funnel,
  };
}

export type DashboardData = ReturnType<typeof getMockDashboardData>;
